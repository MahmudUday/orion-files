package com.orion.files

import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.PriorityQueue
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class Volume(val name: String, val root: File, val total: Long, val free: Long)

object FileOps {

    val root: File get() = Environment.getExternalStorageDirectory()

    fun comparator(by: SortBy, asc: Boolean): Comparator<File> {
        val base: Comparator<File> = when (by) {
            SortBy.Name -> compareBy<File> { it.name.lowercase() }
            SortBy.Date -> compareBy<File> { it.lastModified() }
            SortBy.Size -> compareBy<File> { if (it.isDirectory) 0L else it.length() }
            SortBy.Type -> compareBy<File>({ it.ext }, { it.name.lowercase() })
        }
        val dirsFirst = compareBy<File> { !it.isDirectory }
        val ordered = if (asc) base else base.reversed()
        return dirsFirst.then(ordered)
    }

    fun list(dir: File, hidden: Boolean, by: SortBy, asc: Boolean): List<File> {
        val all = dir.listFiles() ?: return emptyList()
        return all.filter { hidden || !it.name.startsWith(".") }.sortedWith(comparator(by, asc))
    }

    fun unique(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot <= 0) name else name.substring(0, dot)
        val ext = if (dot <= 0) "" else name.substring(dot)
        var i = 1
        while (true) {
            f = File(dir, "$base ($i)$ext")
            if (!f.exists()) return f
            i++
        }
    }

    private fun isInside(child: File, parent: File): Boolean {
        val c = child.canonicalPath
        val p = parent.canonicalPath
        return c == p || c.startsWith(p + File.separator)
    }

    fun copyTo(src: File, destDir: File): File {
        if (src.isDirectory) {
            require(!isInside(destDir, src)) { "Cannot copy a folder into itself" }
        }
        val dest = unique(destDir, src.name)
        if (src.isDirectory) {
            src.copyRecursively(dest, overwrite = false)
        } else {
            src.copyTo(dest, overwrite = false)
        }
        return dest
    }

    fun moveTo(src: File, destDir: File): File {
        if (src.parentFile?.canonicalPath == destDir.canonicalPath) return src
        if (src.isDirectory) {
            require(!isInside(destDir, src)) { "Cannot move a folder into itself" }
        }
        val dest = unique(destDir, src.name)
        if (src.renameTo(dest)) return dest
        val copied = copyTo(src, destDir)
        src.deleteRecursively()
        return copied
    }

    fun sizeOf(f: File): Long =
        if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    fun zip(files: List<File>, out: File) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
            for (f in files) {
                val base = f.parentFile ?: f
                for (p in f.walkTopDown()) {
                    val rel = p.relativeTo(base).path.replace(File.separatorChar, '/')
                    if (rel.isEmpty()) continue
                    if (p.isDirectory) {
                        zos.putNextEntry(ZipEntry("$rel/"))
                        zos.closeEntry()
                    } else {
                        zos.putNextEntry(ZipEntry(rel))
                        p.inputStream().use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
            }
        }
    }

    fun unzip(zip: File, destDir: File) {
        destDir.mkdirs()
        val canon = destDir.canonicalPath
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                val out = File(destDir, e.name)
                if (!out.canonicalPath.startsWith(canon + File.separator)) {
                    throw SecurityException("Unsafe zip entry")
                }
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
                zis.closeEntry()
            }
        }
    }

    private fun walk(start: File, hidden: Boolean): Sequence<File> =
        start.walkTopDown().onEnter { d ->
            d == start ||
                (d.name != TrashStore.NAME &&
                    (hidden || !d.name.startsWith(".")) &&
                    !(d.name == "Android" && d.parentFile?.absolutePath == root.absolutePath))
        }

    fun search(start: File, q: String, hidden: Boolean, limit: Int = 300): List<File> =
        walk(start, hidden)
            .filter { it != start && it.name.contains(q, ignoreCase = true) && (hidden || !it.name.startsWith(".")) }
            .take(limit)
            .toList()

    fun scanCategory(cat: Category, hidden: Boolean, limit: Int = 3000): List<File> =
        walk(root, hidden)
            .filter { it.isFile && it.ext in cat.exts && (hidden || !it.name.startsWith(".")) }
            .take(limit)
            .toList()

    fun recent(n: Int = 100): List<File> {
        val heap = PriorityQueue<Pair<Long, File>>(compareBy<Pair<Long, File>> { it.first })
        for (f in walk(root, false)) {
            if (!f.isFile || f.name.startsWith(".")) continue
            heap.add(f.lastModified() to f)
            if (heap.size > n) heap.poll()
        }
        return heap.sortedByDescending { it.first }.map { it.second }
    }

    fun largest(n: Int = 50): List<File> {
        val heap = PriorityQueue<Pair<Long, File>>(compareBy<Pair<Long, File>> { it.first })
        for (f in walk(root, false)) {
            if (!f.isFile || f.name.startsWith(".")) continue
            heap.add(f.length() to f)
            if (heap.size > n) heap.poll()
        }
        return heap.sortedByDescending { it.first }.map { it.second }
    }

    fun volumes(ctx: Context): List<Volume> {
        val list = mutableListOf<Volume>()
        fun add(name: String, f: File) {
            try {
                val st = StatFs(f.absolutePath)
                list.add(Volume(name, f, st.blockCountLong * st.blockSizeLong, st.availableBlocksLong * st.blockSizeLong))
            } catch (e: Exception) {
            }
        }
        add("Internal storage", root)
        val dirs = ctx.getExternalFilesDirs(null)
        for (i in 1 until dirs.size) {
            val d = dirs[i] ?: continue
            val p = d.absolutePath.substringBefore("/Android")
            val r = File(p)
            if (r.exists() && r.canRead()) add("SD card", r)
        }
        return list
    }

    fun publicDirs(): List<Pair<String, File>> = listOf(
        "Downloads" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "Camera (DCIM)" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
        "Pictures" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
        "Documents" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
        "Music" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
        "Movies" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
    ).filter { it.second.exists() }
}

/** Recycle bin stored inside internal storage in a hidden folder. */
object TrashStore {
    const val NAME = ".orion_trash"
    val dir: File get() = File(FileOps.root, NAME)

    private fun metaOf(f: File) = File(dir, f.name + ".meta")

    private fun moveInto(src: File, dest: File) {
        if (!src.renameTo(dest)) {
            src.copyRecursively(dest, overwrite = false)
            src.deleteRecursively()
        }
    }

    fun add(f: File) {
        dir.mkdirs()
        val id = "${System.currentTimeMillis()}_${f.name}"
        val target = File(dir, id)
        val original = f.absolutePath
        moveInto(f, target)
        File(dir, "$id.meta").writeText(original)
    }

    fun items(): List<File> =
        (dir.listFiles() ?: emptyArray())
            .filter { !it.name.endsWith(".meta") }
            .sortedByDescending { it.name }

    fun originalPath(f: File): String? = metaOf(f).takeIf { it.exists() }?.readText()

    fun displayName(f: File): String = f.name.substringAfter('_', f.name)

    fun restore(f: File): File {
        val orig = originalPath(f)?.let { File(it) }
        val destDir = orig?.parentFile ?: File(FileOps.root, "Restored")
        destDir.mkdirs()
        val dest = FileOps.unique(destDir, orig?.name ?: displayName(f))
        moveInto(f, dest)
        metaOf(f).delete()
        return dest
    }

    fun purge(f: File) {
        f.deleteRecursively()
        metaOf(f).delete()
    }

    fun empty() {
        dir.listFiles()?.forEach { it.deleteRecursively() }
    }
}
