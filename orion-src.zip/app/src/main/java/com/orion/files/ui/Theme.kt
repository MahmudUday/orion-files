package com.orion.files.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** Orion palette: AMOLED black with blue + purple accents and glass surfaces. */
object OC {
    val Black = Color(0xFF000000)
    val Blue = Color(0xFF3D7BFF)
    val Purple = Color(0xFF9B5CFF)
    val Cyan = Color(0xFF45D4FF)
    val Pink = Color(0xFFFF6BCB)
    val Gold = Color(0xFFFFC857)
    val Green = Color(0xFF5CE08A)
    val Glass = Color(0x17FFFFFF)
    val GlassHi = Color(0x2BFFFFFF)
    val Text = Color(0xFFF2F4FF)
    val Dim = Color(0xFF9AA0C0)
    val Danger = Color(0xFFFF5C7A)
    val Sheet = Color(0xFF0D0D1A)
}

val OrionBrush: Brush = Brush.linearGradient(listOf(OC.Blue, OC.Purple))

@Composable
fun OrionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = OC.Blue,
            secondary = OC.Purple,
            tertiary = OC.Cyan,
            background = OC.Black,
            surface = OC.Black,
            onPrimary = Color.White,
            onBackground = OC.Text,
            onSurface = OC.Text,
            surfaceVariant = OC.Glass,
            onSurfaceVariant = OC.Dim,
            error = OC.Danger
        ),
        content = content
    )
}

/** Translucent "glass" panel: soft white tint plus a light gradient edge. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(20.dp), strong: Boolean = false): Modifier =
    this
        .clip(shape)
        .background(if (strong) OC.GlassHi else OC.Glass)
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color(0x55FFFFFF), Color(0x14FFFFFF), Color(0x44B58CFF))),
            shape
        )

/** Pure black base with soft blue and purple glows. */
@Composable
fun Aurora() {
    Box(
        Modifier
            .fillMaxSize()
            .background(OC.Black)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(OC.Blue.copy(alpha = 0.30f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.02f),
                        radius = size.width * 1.0f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(OC.Purple.copy(alpha = 0.28f), Color.Transparent),
                        center = Offset(size.width * 0.0f, size.height * 0.98f),
                        radius = size.width * 1.1f
                    )
                )
            }
    )
}
