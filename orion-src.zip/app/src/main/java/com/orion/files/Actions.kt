package com.orion.files

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

fun mimeOf(f: File): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.ext) ?: "*/*"

fun uriFor(ctx: Context, f: File): Uri =
    FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

fun openExternally(ctx: Context, f: File) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriFor(ctx, f), mimeOf(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app found to open this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot open: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

fun shareFiles(ctx: Context, files: List<File>) {
    val onlyFiles = files.filter { it.isFile }
    if (onlyFiles.isEmpty()) {
        Toast.makeText(ctx, "Folders cannot be shared. Zip them first.", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val intent = if (onlyFiles.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = mimeOf(onlyFiles[0])
                putExtra(Intent.EXTRA_STREAM, uriFor(ctx, onlyFiles[0]))
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(
                    Intent.EXTRA_STREAM,
                    ArrayList(onlyFiles.map { uriFor(ctx, it) })
                )
            }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val chooser = Intent.createChooser(intent, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(chooser)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot share: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
