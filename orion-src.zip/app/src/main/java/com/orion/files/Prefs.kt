package com.orion.files

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("orion", Context.MODE_PRIVATE)

    var showHidden by mutableStateOf(sp.getBoolean("hidden", false))
        private set
    var useTrash by mutableStateOf(sp.getBoolean("trash", true))
        private set
    var grid by mutableStateOf(sp.getBoolean("grid", false))
        private set
    var thumbs by mutableStateOf(sp.getBoolean("thumbs", true))
        private set
    var sortBy by mutableStateOf(
        runCatching { SortBy.valueOf(sp.getString("sortBy", "Name") ?: "Name") }.getOrDefault(SortBy.Name)
    )
        private set
    var asc by mutableStateOf(sp.getBoolean("asc", true))
        private set
    var favorites by mutableStateOf<Set<String>>(sp.getStringSet("fav", emptySet())?.toSet() ?: emptySet())
        private set

    fun setHidden(v: Boolean) {
        showHidden = v
        sp.edit().putBoolean("hidden", v).apply()
    }

    fun setUseTrash(v: Boolean) {
        useTrash = v
        sp.edit().putBoolean("trash", v).apply()
    }

    fun setGrid(v: Boolean) {
        grid = v
        sp.edit().putBoolean("grid", v).apply()
    }

    fun setThumbs(v: Boolean) {
        thumbs = v
        sp.edit().putBoolean("thumbs", v).apply()
    }

    fun setSort(by: SortBy, ascending: Boolean) {
        sortBy = by
        asc = ascending
        sp.edit().putString("sortBy", by.name).putBoolean("asc", ascending).apply()
    }

    fun toggleFavorites(paths: List<String>) {
        val allFav = paths.all { it in favorites }
        favorites = if (allFav) favorites - paths.toSet() else favorites + paths
        sp.edit().putStringSet("fav", favorites.toSet()).apply()
    }
}
