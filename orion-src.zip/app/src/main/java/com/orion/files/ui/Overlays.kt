package com.orion.files.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.orion.files.Dialog
import com.orion.files.FileOps
import com.orion.files.ImageSession
import com.orion.files.MainViewModel
import com.orion.files.SortBy
import com.orion.files.formatDate
import com.orion.files.formatSize
import com.orion.files.mimeOf
import com.orion.files.openExternally
import com.orion.files.shareFiles
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ------------------------------------------------------------------ dialogs

@Composable
fun DialogHost(vm: MainViewModel) {
    val d = vm.dialog ?: return
    val close = { vm.dialog = null }
    when (d) {
        is Dialog.NewFolder ->
            TextPrompt("New folder", "Folder name", "", "Create", close) { vm.createFolder(it); close() }
        is Dialog.NewFile ->
            TextPrompt("New file", "File name, e.g. note.txt", "", "Create", close) { vm.createFile(it); close() }
        is Dialog.SearchDlg ->
            TextPrompt("Search", "Name contains…", "", "Search", close) { vm.search(it); close() }
        is Dialog.Rename ->
            TextPrompt("Rename", "New name", d.file.name, "Rename", close) { vm.rename(d.file, it); close() }
        is Dialog.Delete -> DeleteDialog(vm, d.files, close)
        is Dialog.EmptyTrash -> ConfirmDialog(
            "Empty recycle bin?",
            "Everything in the recycle bin will be deleted forever.",
            "Empty",
            close
        ) { vm.emptyTrash(); close() }
        is Dialog.Props -> PropsDialog(d.file, close)
        is Dialog.Archive -> ArchiveDialog(vm, d.file, close)
        is Dialog.Sort -> SortDialog(vm, close)
    }
}

@Composable
private fun OrionAlert(
    title: String,
    onDismiss: () -> Unit,
    confirm: @Composable () -> Unit,
    dismissButton: @Composable (() -> Unit)? = null,
    body: @Composable () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OC.Sheet,
        titleContentColor = OC.Text,
        textContentColor = OC.Dim,
        shape = RoundedCornerShape(26.dp),
        title = { Text(title, fontWeight = FontWeight.SemiBold) },
        text = body,
        confirmButton = confirm,
        dismissButton = dismissButton
    )
}

@Composable
fun TextPrompt(
    title: String,
    hint: String,
    initial: String,
    action: String,
    onDismiss: () -> Unit,
    onOk: (String) -> Unit
) {
    val baseLen = initial.substringBeforeLast('.', initial).length
    var text by remember { mutableStateOf(TextFieldValue(initial, TextRange(0, baseLen))) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    OrionAlert(
        title = title,
        onDismiss = onDismiss,
        confirm = { TextButton(onClick = { onOk(text.text) }) { Text(action, color = OC.Blue) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = OC.Dim) } }
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            placeholder = { Text(hint) },
            modifier = Modifier.focusRequester(focus),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = OC.Blue,
                unfocusedBorderColor = OC.Dim,
                cursorColor = OC.Blue,
                focusedTextColor = OC.Text,
                unfocusedTextColor = OC.Text
            )
        )
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    action: String,
    onDismiss: () -> Unit,
    onOk: () -> Unit
) {
    OrionAlert(
        title = title,
        onDismiss = onDismiss,
        confirm = { TextButton(onClick = onOk) { Text(action, color = OC.Danger) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = OC.Dim) } }
    ) { Text(message) }
}

@Composable
fun DeleteDialog(vm: MainViewModel, files: List<File>, onDismiss: () -> Unit) {
    val inTrash = vm.inTrash
    val toBin = vm.prefs.useTrash && !inTrash
    val label = if (files.size == 1) "\"${files[0].name}\"" else "${files.size} items"
    OrionAlert(
        title = if (toBin) "Move to recycle bin?" else "Delete forever?",
        onDismiss = onDismiss,
        confirm = {
            TextButton(onClick = { vm.delete(files, false); onDismiss() }) {
                Text(if (toBin) "Move" else "Delete", color = OC.Danger)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = OC.Dim) } }
    ) {
        Column {
            Text(if (toBin) "$label will be moved to the recycle bin." else "$label will be deleted permanently.")
            if (toBin) {
                TextButton(onClick = { vm.delete(files, true); onDismiss() }) {
                    Text("Delete permanently instead", color = OC.Danger)
                }
            }
        }
    }
}

@Composable
fun PropsDialog(f: File, onDismiss: () -> Unit) {
    val size by produceState(initialValue = -1L, f) {
        value = withContext(Dispatchers.IO) { runCatching { FileOps.sizeOf(f) }.getOrDefault(0L) }
    }
    OrionAlert(
        title = "Properties",
        onDismiss = onDismiss,
        confirm = { TextButton(onClick = onDismiss) { Text("Close", color = OC.Blue) } }
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            PropLine("Name", f.name)
            PropLine("Location", f.parent ?: "/")
            PropLine("Type", if (f.isDirectory) "Folder" else mimeOf(f))
            PropLine("Size", if (size < 0) "Calculating…" else "${formatSize(size)} ($size bytes)")
            if (f.isDirectory) PropLine("Contains", "${f.list()?.size ?: 0} items")
            PropLine("Modified", formatDate(f.lastModified()))
            PropLine("Access", (if (f.canRead()) "Read" else "") + (if (f.canWrite()) " · Write" else ""))
        }
    }
}

@Composable
private fun PropLine(label: String, value: String) {
    Column(Modifier.padding(vertical = 5.dp)) {
        Text(label, color = OC.Dim, fontSize = 11.sp)
        Text(value, color = OC.Text, fontSize = 14.sp)
    }
}

@Composable
fun ArchiveDialog(vm: MainViewModel, f: File, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    OrionAlert(
        title = f.name,
        onDismiss = onDismiss,
        confirm = {
            TextButton(onClick = { vm.extract(f, true); onDismiss() }) { Text("Extract to folder", color = OC.Blue) }
        },
        dismissButton = {
            TextButton(onClick = { vm.extract(f, false); onDismiss() }) { Text("Extract here", color = OC.Blue) }
        }
    ) {
        Column {
            Text("${formatSize(f.length())} zip archive")
            TextButton(onClick = { openExternally(ctx, f); onDismiss() }) {
                Text("Open with another app", color = OC.Dim)
            }
        }
    }
}

@Composable
fun SortDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var sortBy by remember { mutableStateOf(vm.prefs.sortBy) }
    var ascending by remember { mutableStateOf(vm.prefs.asc) }
    OrionAlert(
        title = "Sort by",
        onDismiss = onDismiss,
        confirm = {
            TextButton(onClick = { vm.setSort(sortBy, ascending); onDismiss() }) { Text("Apply", color = OC.Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = OC.Dim) } }
    ) {
        Column {
            SortBy.values().forEach { s ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { sortBy = s },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = sortBy == s,
                        onClick = { sortBy = s },
                        colors = RadioButtonDefaults.colors(selectedColor = OC.Blue, unselectedColor = OC.Dim)
                    )
                    Text(s.label, color = OC.Text)
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (ascending) "Ascending (A → Z, old → new)" else "Descending (Z → A, new → old)", color = OC.Text, modifier = Modifier.weight(1f))
                Switch(
                    checked = ascending,
                    onCheckedChange = { ascending = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = OC.Blue)
                )
            }
        }
    }
}

// ------------------------------------------------------------------ image viewer

@Composable
fun ImageViewer(vm: MainViewModel, s: ImageSession) {
    val ctx = LocalContext.current
    BackHandler { vm.imageViewer = null }
    val pager = rememberPagerState(initialPage = s.index) { s.images.size }
    var zoomed by remember { mutableStateOf(false) }
    val current = s.images[pager.currentPage.coerceIn(0, s.images.lastIndex)]

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        HorizontalPager(
            state = pager,
            userScrollEnabled = !zoomed,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            ZoomImage(s.images[page]) { zoomed = it }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(12.dp)
                .glass(RoundedCornerShape(22.dp), strong = true)
                .padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBtn(Icons.Rounded.ArrowBack) { vm.imageViewer = null }
            Column(Modifier.weight(1f)) {
                Text(current.name, color = OC.Text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(
                    "${pager.currentPage + 1} / ${s.images.size} · ${formatSize(current.length())}",
                    color = OC.Dim,
                    fontSize = 12.sp
                )
            }
            IconBtn(Icons.Rounded.Share) { shareFiles(ctx, listOf(current)) }
        }
    }
}

@Composable
fun ZoomImage(f: File, onZoom: (Boolean) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    AsyncImage(
        model = f,
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        if (event.changes.size >= 2 || scale > 1f) {
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            if (zoom != 1f || pan != Offset.Zero) {
                                scale = (scale * zoom).coerceIn(1f, 6f)
                                if (scale <= 1f) {
                                    offset = Offset.Zero
                                } else {
                                    val mx = size.width * (scale - 1f) / 2f
                                    val my = size.height * (scale - 1f) / 2f
                                    offset = Offset(
                                        (offset.x + pan.x).coerceIn(-mx, mx),
                                        (offset.y + pan.y).coerceIn(-my, my)
                                    )
                                }
                                onZoom(scale > 1f)
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1f) {
                        scale = 1f
                        offset = Offset.Zero
                        onZoom(false)
                    } else {
                        scale = 2.5f
                        onZoom(true)
                    }
                })
            }
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offset.x
                translationY = offset.y
            }
    )
}

// ------------------------------------------------------------------ text editor

@Composable
fun TextEditor(vm: MainViewModel, f: File) {
    val ctx = LocalContext.current
    val initial = remember(f) { runCatching { f.readText() }.getOrDefault("") }
    var text by remember(f) { mutableStateOf(initial) }
    var saved by remember(f) { mutableStateOf(initial) }
    var confirmClose by remember { mutableStateOf(false) }
    val dirty = text != saved

    BackHandler { if (dirty) confirmClose = true else vm.editor = null }

    Box(Modifier.fillMaxSize()) {
        Aurora()
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .navigationBarsPadding()
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .glass(RoundedCornerShape(22.dp), strong = true)
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBtn(Icons.Rounded.Close) { if (dirty) confirmClose = true else vm.editor = null }
                Column(Modifier.weight(1f)) {
                    Text(f.name, color = OC.Text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    if (dirty) Text("Unsaved changes", color = OC.Gold, fontSize = 11.sp)
                }
                GradientButton("Save") {
                    runCatching { f.writeText(text) }
                        .onSuccess {
                            saved = text
                            Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
                        }
                        .onFailure {
                            Toast.makeText(ctx, "Could not save: ${it.message}", Toast.LENGTH_SHORT).show()
                        }
                }
                Spacer(Modifier.width(6.dp))
            }
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .glass(RoundedCornerShape(18.dp))
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp)
            ) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    textStyle = TextStyle(color = OC.Text, fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                    cursorBrush = SolidColor(OC.Blue),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (confirmClose) {
        OrionAlert(
            title = "Discard changes?",
            onDismiss = { confirmClose = false },
            confirm = {
                TextButton(onClick = { confirmClose = false; vm.editor = null }) { Text("Discard", color = OC.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClose = false }) { Text("Keep editing", color = OC.Blue) }
            }
        ) { Text("Your unsaved changes will be lost.") }
    }
}
