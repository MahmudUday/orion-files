package com.orion.files.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RestoreFromTrash
import androidx.compose.material.icons.rounded.SdCard
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.orion.files.Category
import com.orion.files.Dialog
import com.orion.files.FileOps
import com.orion.files.MainViewModel
import com.orion.files.Route
import com.orion.files.TrashStore
import com.orion.files.Volume
import com.orion.files.formatSize
import com.orion.files.openExternally
import com.orion.files.shareFiles
import java.io.File

// ------------------------------------------------------------------ root

@Composable
fun OrionApp(vm: MainViewModel, hasAccess: Boolean, onRequestAccess: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Aurora()
        if (!hasAccess) PermissionScreen(onRequestAccess) else MainContent(vm)
    }
}

@Composable
fun MainContent(vm: MainViewModel) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }
    BackHandler(enabled = vm.selection.isNotEmpty() || vm.stack.size > 1) { vm.back() }

    val r = vm.route
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            AppTopBar(vm)
            if (r is Route.Browse) Crumbs(r.dir) { vm.jump(it) }
            Box(Modifier.weight(1f)) {
                when (r) {
                    is Route.Home -> HomeScreen(vm)
                    is Route.Settings -> SettingsScreen(vm)
                    else -> FileListScreen(vm)
                }
                if (r is Route.Browse && vm.selection.isEmpty()) {
                    NewFab(vm, Modifier.align(Alignment.BottomEnd).padding(20.dp))
                }
            }
            BottomArea(vm)
        }
        SnackbarHost(
            snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 88.dp)
        ) { data -> Snackbar(data, containerColor = OC.Sheet, contentColor = OC.Text) }

        DialogHost(vm)
        vm.imageViewer?.let { ImageViewer(vm, it) }
        vm.editor?.let { TextEditor(vm, it) }
    }
}

@Composable
fun PermissionScreen(onRequestAccess: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        GradientCircleIcon(Icons.Rounded.FolderOpen, size = 88.dp)
        Spacer(Modifier.height(24.dp))
        Text(
            "Allow file access",
            style = TextStyle(brush = OrionBrush, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Orion Files needs access to all files on your phone so it can browse, copy, move and organise them. Nothing leaves your device.",
            color = OC.Dim,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        GradientButton("Grant access", onClick = onRequestAccess)
    }
}

// ------------------------------------------------------------------ bars

fun titleOf(r: Route): String = when (r) {
    is Route.Home -> "Orion Files"
    is Route.Settings -> "Settings"
    is Route.Recent -> "Recent files"
    is Route.Large -> "Large files"
    is Route.Trash -> "Recycle bin"
    is Route.Favs -> "Favorites"
    is Route.Browse -> if (r.dir.absolutePath == FileOps.root.absolutePath) "Internal storage" else r.dir.name
    is Route.Cat -> r.cat.label
    is Route.Search -> "Search: ${r.q}"
}

@Composable
fun AppTopBar(vm: MainViewModel) {
    val r = vm.route
    val n = vm.selection.size
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .glass(RoundedCornerShape(22.dp), strong = true)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        when {
            n > 0 -> {
                IconBtn(Icons.Rounded.Close) { vm.clearSelection() }
                Text("$n selected", color = OC.Text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconBtn(Icons.Rounded.SelectAll) { vm.selectAll() }
            }
            r is Route.Home -> {
                Spacer(Modifier.width(12.dp))
                Text(
                    "Orion Files",
                    style = TextStyle(brush = OrionBrush, fontSize = 22.sp, fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f)
                )
                IconBtn(Icons.Rounded.Search) { vm.dialog = Dialog.SearchDlg }
                IconBtn(Icons.Rounded.Settings) { vm.navigate(Route.Settings) }
            }
            r is Route.Settings -> {
                IconBtn(Icons.Rounded.ArrowBack) { vm.back() }
                Text(titleOf(r), color = OC.Text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            }
            else -> {
                IconBtn(Icons.Rounded.ArrowBack) { vm.back() }
                Text(
                    titleOf(r),
                    color = OC.Text,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (r is Route.Browse) IconBtn(Icons.Rounded.Search) { vm.dialog = Dialog.SearchDlg }
                IconBtn(Icons.Rounded.Sort) { vm.dialog = Dialog.Sort }
                IconBtn(if (vm.prefs.grid) Icons.Rounded.ViewList else Icons.Rounded.GridView) {
                    vm.prefs.setGrid(!vm.prefs.grid)
                }
                Box {
                    IconBtn(Icons.Rounded.MoreVert) { menu = true }
                    DropdownMenu(
                        expanded = menu,
                        onDismissRequest = { menu = false },
                        modifier = Modifier.background(OC.Sheet)
                    ) {
                        DropdownMenuItem(
                            text = { Text(if (vm.prefs.showHidden) "Hide hidden files" else "Show hidden files") },
                            leadingIcon = { Icon(Icons.Rounded.Visibility, null, tint = OC.Dim) },
                            onClick = { menu = false; vm.setHidden(!vm.prefs.showHidden) }
                        )
                        DropdownMenuItem(
                            text = { Text("Refresh") },
                            leadingIcon = { Icon(Icons.Rounded.Refresh, null, tint = OC.Dim) },
                            onClick = { menu = false; vm.refresh() }
                        )
                        if (r is Route.Trash) {
                            DropdownMenuItem(
                                text = { Text("Empty recycle bin") },
                                leadingIcon = { Icon(Icons.Rounded.DeleteSweep, null, tint = OC.Danger) },
                                onClick = { menu = false; vm.dialog = Dialog.EmptyTrash }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActionBtn(icon: ImageVector, label: String, tint: Color = OC.Text, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = tint)
        Text(label, color = tint, fontSize = 11.sp)
    }
}

@Composable
fun BottomArea(vm: MainViewModel) {
    Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
        if (vm.selection.isNotEmpty()) {
            SelectionBar(vm)
        } else if (vm.clip.isNotEmpty() && vm.currentDir != null) {
            PasteBar(vm)
        }
    }
}

@Composable
fun SelectionBar(vm: MainViewModel) {
    val ctx = LocalContext.current
    val sel = vm.selectedFiles()
    var more by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .glass(RoundedCornerShape(24.dp), strong = true)
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (vm.inTrash) {
            ActionBtn(Icons.Rounded.RestoreFromTrash, "Restore") { vm.restoreSelected() }
            ActionBtn(Icons.Rounded.DeleteForever, "Delete", OC.Danger) { vm.dialog = Dialog.Delete(sel) }
        } else {
            ActionBtn(Icons.Rounded.ContentCopy, "Copy") { vm.copySelected() }
            ActionBtn(Icons.Rounded.ContentCut, "Move") { vm.cutSelected() }
            ActionBtn(Icons.Rounded.Delete, "Delete", OC.Danger) { vm.dialog = Dialog.Delete(sel) }
            ActionBtn(Icons.Rounded.Share, "Share") { shareFiles(ctx, sel) }
            Box {
                ActionBtn(Icons.Rounded.MoreVert, "More") { more = true }
                DropdownMenu(
                    expanded = more,
                    onDismissRequest = { more = false },
                    modifier = Modifier.background(OC.Sheet)
                ) {
                    DropdownMenuItem(
                        text = { Text("Compress to zip") },
                        leadingIcon = { Icon(Icons.Rounded.Archive, null, tint = OC.Dim) },
                        onClick = { more = false; vm.zipSelected() }
                    )
                    DropdownMenuItem(
                        text = { Text("Add / remove favorite") },
                        leadingIcon = { Icon(Icons.Rounded.Star, null, tint = OC.Gold) },
                        onClick = { more = false; vm.toggleFavorite(sel) }
                    )
                    if (sel.size == 1) {
                        DropdownMenuItem(
                            text = { Text("Rename") },
                            leadingIcon = { Icon(Icons.Rounded.Edit, null, tint = OC.Dim) },
                            onClick = { more = false; vm.dialog = Dialog.Rename(sel[0]) }
                        )
                        DropdownMenuItem(
                            text = { Text("Properties") },
                            leadingIcon = { Icon(Icons.Rounded.Info, null, tint = OC.Dim) },
                            onClick = { more = false; vm.dialog = Dialog.Props(sel[0]) }
                        )
                        if (sel[0].isFile) {
                            DropdownMenuItem(
                                text = { Text("Open with…") },
                                leadingIcon = { Icon(Icons.Rounded.OpenInNew, null, tint = OC.Dim) },
                                onClick = { more = false; openExternally(ctx, sel[0]) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PasteBar(vm: MainViewModel) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .glass(RoundedCornerShape(24.dp), strong = true)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "${vm.clip.size} item(s) to ${if (vm.clipCut) "move" else "copy"}",
            color = OC.Text,
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = { vm.clearClip() }) { Text("Cancel", color = OC.Dim) }
        GradientButton("Paste") { vm.paste() }
    }
}

@Composable
fun NewFab(vm: MainViewModel, modifier: Modifier = Modifier) {
    var menu by remember { mutableStateOf(false) }
    Box(modifier) {
        Box(
            Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(OrionBrush)
                .clickable { menu = true },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Add, contentDescription = "New", tint = Color.White)
        }
        DropdownMenu(
            expanded = menu,
            onDismissRequest = { menu = false },
            modifier = Modifier.background(OC.Sheet)
        ) {
            DropdownMenuItem(
                text = { Text("New folder") },
                leadingIcon = { Icon(Icons.Rounded.CreateNewFolder, null, tint = OC.Blue) },
                onClick = { menu = false; vm.dialog = Dialog.NewFolder }
            )
            DropdownMenuItem(
                text = { Text("New file") },
                leadingIcon = { Icon(Icons.Rounded.NoteAdd, null, tint = OC.Purple) },
                onClick = { menu = false; vm.dialog = Dialog.NewFile }
            )
        }
    }
}

// ------------------------------------------------------------------ home

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val volumes = remember { FileOps.volumes(ctx) }
    val quick = remember { FileOps.publicDirs() }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp)
    ) {
        items(volumes) { v ->
            StorageCard(v) { vm.openDir(v.root) }
            Spacer(Modifier.height(10.dp))
        }
        item {
            Column {
                SectionTitle("Categories")
                Category.values().toList().chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { c ->
                            CategoryTile(c, Modifier.weight(1f)) { vm.navigate(Route.Cat(c)) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
        item { SectionTitle("Quick access") }
        items(quick) { q ->
            QuickRow(Icons.Rounded.FolderOpen, q.first, OC.Blue) { vm.openDir(q.second) }
        }
        item {
            Column {
                QuickRow(Icons.Rounded.History, "Recent files", OC.Cyan) { vm.navigate(Route.Recent) }
                QuickRow(Icons.Rounded.Storage, "Large files", OC.Purple) { vm.navigate(Route.Large) }
                QuickRow(Icons.Rounded.Star, "Favorites", OC.Gold) { vm.navigate(Route.Favs) }
                QuickRow(Icons.Rounded.Delete, "Recycle bin", OC.Danger) { vm.navigate(Route.Trash) }
            }
        }
    }
}

@Composable
fun StorageCard(v: Volume, onClick: () -> Unit) {
    val used = (v.total - v.free).coerceAtLeast(0L)
    val frac = if (v.total > 0) (used.toDouble() / v.total.toDouble()).toFloat().coerceIn(0f, 1f) else 0f
    Column(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(24.dp), strong = true)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GradientCircleIcon(if (v.name == "SD card") Icons.Rounded.SdCard else Icons.Rounded.Storage)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(v.name, color = OC.Text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("${formatSize(used)} used of ${formatSize(v.total)}", color = OC.Dim, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(50))
                .background(Color(0x22FFFFFF))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(frac)
                    .clip(RoundedCornerShape(50))
                    .background(OrionBrush)
            )
        }
        Spacer(Modifier.height(6.dp))
        Text("${formatSize(v.free)} free", color = OC.Dim, fontSize = 12.sp)
    }
}

@Composable
fun CategoryTile(c: Category, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .glass(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(c.tint().copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(c.icon(), contentDescription = null, tint = c.tint())
        }
        Spacer(Modifier.height(8.dp))
        Text(c.label, color = OC.Text, fontSize = 13.sp)
    }
}

@Composable
fun QuickRow(icon: ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .glass(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint)
        Spacer(Modifier.width(14.dp))
        Text(label, color = OC.Text, modifier = Modifier.weight(1f))
    }
}

// ------------------------------------------------------------------ file list

@Composable
fun FileListScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val list = vm.items
    val selecting = vm.selection.isNotEmpty()
    val trash = vm.inTrash
    val thumbs = vm.prefs.thumbs
    val favs = vm.prefs.favorites
    val r = vm.route
    val root = FileOps.root.absolutePath

    fun titleFor(f: File) = if (trash) TrashStore.displayName(f) else f.name
    fun subFor(f: File): String? = when {
        trash -> TrashStore.originalPath(f) ?: ""
        r is Route.Browse -> null
        else -> (if (f.isFile) formatSize(f.length()) else "Folder") + " · " +
            (f.parent?.removePrefix(root)?.ifEmpty { "/" } ?: "")
    }

    Box(Modifier.fillMaxSize()) {
        if (list.isEmpty() && !vm.loading) {
            Text(
                if (trash) "Recycle bin is empty" else "Nothing here",
                color = OC.Dim,
                modifier = Modifier.align(Alignment.Center)
            )
        }
        if (vm.prefs.grid) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(110.dp),
                contentPadding = PaddingValues(12.dp, 4.dp, 12.dp, 110.dp)
            ) {
                items(list, key = { it.absolutePath }) { f ->
                    FileCell(
                        f = f,
                        title = titleFor(f),
                        selected = f.absolutePath in vm.selection,
                        selecting = selecting,
                        fav = f.absolutePath in favs,
                        thumbs = thumbs,
                        onClick = { vm.onClick(ctx, f) },
                        onLong = { vm.onLongClick(f) }
                    )
                }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 110.dp)) {
                items(list, key = { it.absolutePath }) { f ->
                    FileRow(
                        f = f,
                        title = titleFor(f),
                        subtitle = subFor(f),
                        selected = f.absolutePath in vm.selection,
                        selecting = selecting,
                        fav = f.absolutePath in favs,
                        thumbs = thumbs,
                        onClick = { vm.onClick(ctx, f) },
                        onLong = { vm.onLongClick(f) }
                    )
                }
            }
        }
        if (vm.loading) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter),
                color = OC.Purple,
                trackColor = Color.Transparent
            )
        }
    }
}

// ------------------------------------------------------------------ settings

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        SettingRow("Show hidden files", "Files and folders starting with a dot", p.showHidden) { vm.setHidden(it) }
        SettingRow("Recycle bin", "Deleted items go to the recycle bin first", p.useTrash) { p.setUseTrash(it) }
        SettingRow("Thumbnails", "Preview photos and videos in lists", p.thumbs) { p.setThumbs(it) }
        SettingRow("Grid view", "Show files as a grid by default", p.grid) { p.setGrid(it) }
        Spacer(Modifier.height(12.dp))
        QuickRow(Icons.Rounded.DeleteSweep, "Empty recycle bin", OC.Danger) { vm.dialog = Dialog.EmptyTrash }
        Spacer(Modifier.height(24.dp))
        Text(
            "Orion Files 1.0 · File manager for ORION",
            color = OC.Dim,
            fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
fun SettingRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .glass(RoundedCornerShape(18.dp))
            .clickable { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = OC.Text, fontWeight = FontWeight.Medium)
            Text(subtitle, color = OC.Dim, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = OC.Blue,
                uncheckedThumbColor = OC.Dim,
                uncheckedTrackColor = Color(0x22FFFFFF)
            )
        )
    }
}
