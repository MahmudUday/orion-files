package com.orion.files

import java.io.File
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Category(val label: String, val exts: Set<String>) {
    Images("Images", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")),
    Videos("Videos", setOf("mp4", "mkv", "webm", "3gp", "avi", "mov", "m4v", "flv")),
    Audio("Audio", setOf("mp3", "wav", "m4a", "aac", "ogg", "flac", "opus", "amr")),
    Documents(
        "Documents",
        setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "odt", "csv", "epub", "md")
    ),
    Archives("Archives", setOf("zip", "rar", "7z", "tar", "gz")),
    Apks("APKs", setOf("apk", "xapk", "apks"));
}

val TEXT_EXTS = setOf(
    "txt", "md", "json", "xml", "log", "csv", "html", "htm", "css", "js", "kt", "java",
    "py", "ini", "conf", "yml", "yaml", "properties", "gradle", "sh", "c", "cpp", "h", "srt", "vcf"
)

enum class SortBy(val label: String) {
    Name("Name"), Date("Date modified"), Size("Size"), Type("Type")
}

val File.ext: String get() = extension.lowercase()

fun File.category(): Category? {
    val e = ext
    return Category.values().firstOrNull { e in it.exts }
}

fun File.isImage(): Boolean = isFile && category() == Category.Images

fun formatSize(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var i = 0
    while (v >= 1024.0 && i < units.lastIndex) {
        v /= 1024.0
        i++
    }
    val num = if (i == 0) v.toLong().toString() else DecimalFormat("#.##").format(v)
    return num + " " + units[i]
}

fun formatDate(ms: Long): String =
    SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))

/** Navigation destinations. */
sealed interface Route {
    object Home : Route
    object Settings : Route
    object Recent : Route
    object Large : Route
    object Trash : Route
    object Favs : Route
    class Browse(val dir: File) : Route
    class Cat(val cat: Category) : Route
    class Search(val root: File, val q: String) : Route
}

/** Dialogs shown over the screen. */
sealed interface Dialog {
    object NewFolder : Dialog
    object NewFile : Dialog
    object SearchDlg : Dialog
    object EmptyTrash : Dialog
    object Sort : Dialog
    class Rename(val file: File) : Dialog
    class Delete(val files: List<File>) : Dialog
    class Props(val file: File) : Dialog
    class Archive(val file: File) : Dialog
}

class ImageSession(val images: List<File>, val index: Int)
