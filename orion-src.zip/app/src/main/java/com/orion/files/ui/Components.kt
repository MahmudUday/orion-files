package com.orion.files.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.orion.files.Category
import com.orion.files.FileOps
import com.orion.files.TEXT_EXTS
import com.orion.files.category
import com.orion.files.ext
import com.orion.files.formatDate
import com.orion.files.formatSize
import java.io.File

fun iconFor(f: File): ImageVector = when {
    f.isDirectory -> Icons.Rounded.Folder
    f.ext == "pdf" -> Icons.Rounded.PictureAsPdf
    else -> when (f.category()) {
        Category.Images -> Icons.Rounded.Image
        Category.Videos -> Icons.Rounded.VideoFile
        Category.Audio -> Icons.Rounded.AudioFile
        Category.Documents -> Icons.Rounded.Description
        Category.Archives -> Icons.Rounded.FolderZip
        Category.Apks -> Icons.Rounded.Android
        null -> if (f.ext in TEXT_EXTS) Icons.Rounded.Description else Icons.Rounded.InsertDriveFile
    }
}

fun tintFor(f: File): Color = when {
    f.isDirectory -> OC.Blue
    f.ext == "pdf" -> OC.Danger
    else -> when (f.category()) {
        Category.Images -> OC.Cyan
        Category.Videos -> OC.Purple
        Category.Audio -> OC.Pink
        Category.Documents -> Color(0xFF7FB2FF)
        Category.Archives -> OC.Gold
        Category.Apks -> OC.Green
        null -> OC.Dim
    }
}

fun Category.icon(): ImageVector = when (this) {
    Category.Images -> Icons.Rounded.Image
    Category.Videos -> Icons.Rounded.VideoFile
    Category.Audio -> Icons.Rounded.AudioFile
    Category.Documents -> Icons.Rounded.Description
    Category.Archives -> Icons.Rounded.FolderZip
    Category.Apks -> Icons.Rounded.Android
}

fun Category.tint(): Color = when (this) {
    Category.Images -> OC.Cyan
    Category.Videos -> OC.Purple
    Category.Audio -> OC.Pink
    Category.Documents -> Color(0xFF7FB2FF)
    Category.Archives -> OC.Gold
    Category.Apks -> OC.Green
}

fun subtitleOf(f: File): String =
    if (f.isDirectory) "${f.list()?.size ?: 0} items · ${formatDate(f.lastModified())}"
    else "${formatSize(f.length())} · ${formatDate(f.lastModified())}"

@Composable
fun IconBtn(icon: ImageVector, tint: Color = OC.Text, onClick: () -> Unit) {
    IconButton(onClick = onClick) { Icon(icon, contentDescription = null, tint = tint) }
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(OrionBrush)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        color = OC.Dim,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 14.dp, bottom = 8.dp, start = 4.dp)
    )
}

@Composable
fun Thumb(f: File, size: Dp, thumbs: Boolean, modifier: Modifier = Modifier) {
    val cat = remember(f.absolutePath) { if (f.isDirectory) null else f.category() }
    val showImg = thumbs && (cat == Category.Images || cat == Category.Videos)
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(Color(0x333D7BFF), Color(0x339B5CFF)))),
        contentAlignment = Alignment.Center
    ) {
        Icon(iconFor(f), contentDescription = null, tint = tintFor(f), modifier = Modifier.size(size * 0.5f))
        if (showImg) {
            AsyncImage(
                model = f,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun SelectDot(selected: Boolean) {
    Icon(
        if (selected) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
        contentDescription = null,
        tint = if (selected) OC.Blue else OC.Dim
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(
    f: File,
    title: String,
    subtitle: String?,
    selected: Boolean,
    selecting: Boolean,
    fav: Boolean,
    thumbs: Boolean,
    onClick: () -> Unit,
    onLong: () -> Unit
) {
    val sub = subtitle ?: remember(f.absolutePath, f.lastModified()) { subtitleOf(f) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .glass(RoundedCornerShape(18.dp), strong = selected)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(f, 48.dp, thumbs)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = OC.Text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(sub, color = OC.Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (fav) {
            Icon(Icons.Rounded.Star, contentDescription = null, tint = OC.Gold, modifier = Modifier.size(18.dp))
        }
        if (selecting) {
            Spacer(Modifier.width(8.dp))
            SelectDot(selected)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileCell(
    f: File,
    title: String,
    selected: Boolean,
    selecting: Boolean,
    fav: Boolean,
    thumbs: Boolean,
    onClick: () -> Unit,
    onLong: () -> Unit
) {
    Column(
        Modifier
            .padding(4.dp)
            .glass(RoundedCornerShape(18.dp), strong = selected)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Thumb(f, 88.dp, thumbs)
            if (selecting) SelectDot(selected)
            else if (fav) Icon(Icons.Rounded.Star, contentDescription = null, tint = OC.Gold, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            title,
            color = OC.Text,
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun Crumbs(dir: File, onJump: (File) -> Unit) {
    val parts = remember(dir.absolutePath) {
        val list = mutableListOf<Pair<String, File>>()
        var cur: File? = dir
        while (cur != null) {
            val name = if (cur.parentFile == null) "/" else cur.name
            list.add(0, name to cur)
            cur = cur.parentFile
        }
        val rootAbs = FileOps.root.absolutePath
        val idx = list.indexOfFirst { it.second.absolutePath == rootAbs }
        if (idx >= 0) listOf("Internal" to list[idx].second) + list.drop(idx + 1) else list.toList()
    }
    val scroll = rememberScrollState()
    LaunchedEffect(parts.size) { scroll.scrollTo(scroll.maxValue) }
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(scroll)
            .padding(horizontal = 12.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        parts.forEachIndexed { i, part ->
            if (i > 0) Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = OC.Dim, modifier = Modifier.size(18.dp))
            Text(
                part.first,
                color = if (i == parts.lastIndex) OC.Text else OC.Blue,
                fontSize = 14.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onJump(part.second) }
                    .padding(horizontal = 6.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
fun GradientCircleIcon(icon: ImageVector, size: Dp = 44.dp, tint: Color = Color.White) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(OrionBrush),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}
