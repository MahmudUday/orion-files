package com.orion.files

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)

    val stack = mutableStateListOf<Route>(Route.Home)
    val route: Route get() = stack[stack.lastIndex]

    var items by mutableStateOf<List<File>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set

    val selection = mutableStateListOf<String>()

    var clip by mutableStateOf<List<File>>(emptyList())
        private set
    var clipCut by mutableStateOf(false)
        private set

    var dialog by mutableStateOf<Dialog?>(null)
    var imageViewer by mutableStateOf<ImageSession?>(null)
    var editor by mutableStateOf<File?>(null)

    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)

    private var loadJob: Job? = null

    val currentDir: File? get() = (route as? Route.Browse)?.dir
    val inTrash: Boolean get() = route is Route.Trash

    // ---------- navigation ----------

    fun navigate(r: Route) {
        selection.clear()
        stack.add(r)
        load()
    }

    fun openDir(dir: File) = navigate(Route.Browse(dir))

    /** Replace the current folder (used by the breadcrumb). */
    fun jump(dir: File) {
        selection.clear()
        stack[stack.lastIndex] = Route.Browse(dir)
        load()
    }

    fun back(): Boolean {
        if (selection.isNotEmpty()) {
            selection.clear()
            return true
        }
        if (stack.size > 1) {
            stack.removeAt(stack.lastIndex)
            load()
            return true
        }
        return false
    }

    fun refresh() = load()

    fun load() {
        loadJob?.cancel()
        val r = route
        if (r is Route.Home || r is Route.Settings) {
            items = emptyList()
            loading = false
            return
        }
        val hidden = prefs.showHidden
        val by = prefs.sortBy
        val asc = prefs.asc
        val favs = prefs.favorites
        loadJob = viewModelScope.launch {
            loading = true
            val res: List<File> = withContext(Dispatchers.IO) {
                try {
                    when (r) {
                        is Route.Browse -> FileOps.list(r.dir, hidden, by, asc)
                        is Route.Cat -> FileOps.scanCategory(r.cat, hidden).sortedWith(FileOps.comparator(by, asc))
                        is Route.Recent -> FileOps.recent()
                        is Route.Large -> FileOps.largest()
                        is Route.Trash -> TrashStore.items()
                        is Route.Favs -> favs.map { File(it) }.filter { it.exists() }
                            .sortedWith(FileOps.comparator(by, asc))
                        is Route.Search -> FileOps.search(r.root, r.q, hidden)
                        else -> emptyList<File>()
                    }
                } catch (e: Exception) {
                    emptyList<File>()
                }
            }
            items = res
            loading = false
        }
    }

    // ---------- selection ----------

    fun toggle(f: File) {
        val p = f.absolutePath
        if (p in selection) selection.remove(p) else selection.add(p)
    }

    fun selectAll() {
        selection.clear()
        selection.addAll(items.map { it.absolutePath })
    }

    fun clearSelection() = selection.clear()

    fun selectedFiles(): List<File> = items.filter { it.absolutePath in selection }

    // ---------- opening ----------

    fun onClick(ctx: Context, f: File) {
        if (selection.isNotEmpty() || inTrash) {
            toggle(f)
            return
        }
        open(ctx, f)
    }

    fun onLongClick(f: File) = toggle(f)

    fun open(ctx: Context, f: File) {
        when {
            f.isDirectory -> openDir(f)
            f.isImage() -> {
                val imgs = items.filter { it.isImage() }.ifEmpty { listOf(f) }
                val idx = imgs.indexOfFirst { it.absolutePath == f.absolutePath }.coerceAtLeast(0)
                imageViewer = ImageSession(imgs, idx)
            }
            f.ext in TEXT_EXTS && f.length() < 1_000_000L -> editor = f
            f.ext == "zip" -> dialog = Dialog.Archive(f)
            else -> openExternally(ctx, f)
        }
    }

    // ---------- operations ----------

    private fun runOp(success: String, after: () -> Unit = {}, block: () -> Unit) {
        viewModelScope.launch {
            loading = true
            val err = withContext(Dispatchers.IO) { runCatching(block).exceptionOrNull() }
            loading = false
            selection.clear()
            after()
            messages.tryEmit(if (err != null) "Failed: ${err.message ?: "unknown error"}" else success)
            load()
        }
    }

    fun createFolder(name: String) {
        val dir = currentDir ?: return
        val n = name.trim()
        if (!validName(n)) return
        runOp("Folder created") {
            val f = File(dir, n)
            if (f.exists()) error("Already exists")
            if (!f.mkdirs()) error("Cannot create folder")
        }
    }

    fun createFile(name: String) {
        val dir = currentDir ?: return
        val n = name.trim()
        if (!validName(n)) return
        runOp("File created") {
            val f = File(dir, n)
            if (f.exists()) error("Already exists")
            if (!f.createNewFile()) error("Cannot create file")
        }
    }

    fun rename(f: File, newName: String) {
        val n = newName.trim()
        if (!validName(n)) return
        runOp("Renamed") {
            val dest = File(f.parentFile, n)
            if (dest.exists()) error("A file with that name exists")
            if (!f.renameTo(dest)) error("Rename failed")
        }
    }

    fun validName(n: String): Boolean {
        if (n.isEmpty() || n.contains('/') || n == "." || n == "..") {
            messages.tryEmit("Invalid name")
            return false
        }
        return true
    }

    fun delete(files: List<File>, permanent: Boolean) {
        val toTrash = prefs.useTrash && !permanent && !inTrash
        runOp(if (toTrash) "Moved to recycle bin" else "Deleted") {
            for (f in files) {
                if (inTrash) {
                    TrashStore.purge(f)
                } else if (toTrash) {
                    TrashStore.add(f)
                } else if (!f.deleteRecursively()) {
                    error("Could not delete ${f.name}")
                }
            }
        }
    }

    fun copySelected() {
        clip = selectedFiles()
        clipCut = false
        selection.clear()
        messages.tryEmit("${clip.size} copied. Open a folder and paste.")
    }

    fun cutSelected() {
        clip = selectedFiles()
        clipCut = true
        selection.clear()
        messages.tryEmit("${clip.size} ready to move. Open a folder and paste.")
    }

    fun clearClip() {
        clip = emptyList()
    }

    fun paste() {
        val dest = currentDir ?: return
        val files = clip
        val cut = clipCut
        runOp(if (cut) "Moved" else "Copied", after = { clip = emptyList() }) {
            files.forEach { if (cut) FileOps.moveTo(it, dest) else FileOps.copyTo(it, dest) }
        }
    }

    fun zipSelected() {
        val files = selectedFiles()
        if (files.isEmpty()) return
        val parent = files[0].parentFile ?: return
        val name = if (files.size == 1) files[0].nameWithoutExtension + ".zip" else "Archive.zip"
        runOp("Zip created") {
            FileOps.zip(files, FileOps.unique(parent, name))
        }
    }

    fun extract(zip: File, toFolder: Boolean) {
        val parent = zip.parentFile ?: return
        runOp("Extracted") {
            val dest = if (toFolder) FileOps.unique(parent, zip.nameWithoutExtension) else parent
            FileOps.unzip(zip, dest)
        }
    }

    fun toggleFavorite(files: List<File>) {
        prefs.toggleFavorites(files.map { it.absolutePath })
        selection.clear()
        if (route is Route.Favs) load()
    }

    fun restoreSelected() {
        val files = selectedFiles()
        runOp("Restored") { files.forEach { TrashStore.restore(it) } }
    }

    fun emptyTrash() {
        runOp("Recycle bin emptied") { TrashStore.empty() }
    }

    fun search(q: String) {
        val text = q.trim()
        if (text.isEmpty()) return
        val start = currentDir ?: FileOps.root
        navigate(Route.Search(start, text))
    }

    fun setSort(by: SortBy, asc: Boolean) {
        prefs.setSort(by, asc)
        load()
    }

    fun setHidden(v: Boolean) {
        prefs.setHidden(v)
        load()
    }
}
